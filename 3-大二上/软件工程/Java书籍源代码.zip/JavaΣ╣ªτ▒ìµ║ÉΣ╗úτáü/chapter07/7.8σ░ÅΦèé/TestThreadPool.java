import java.util.concurrent.*;
public class TestThreadPool {
	public static void main(String[] args) {
		ExecutorService es = Executors.newFixedThreadPool(10);
		Runnable run = new Runnable() {
			public void run() {
				for (int i = 0; i < 3; i++) {
					System.out.println(Thread.currentThread().getName()
							+ "ִ���˵�" + i + "��");
				}
			}
		};
		es.submit(run);
		es.submit(run);
		es.shutdown();
	}
}