public class TestJoin {
	public static void main(String[] args) throws Exception {
		SubThread4 st = new SubThread4(); 	// ����SubThread4ʵ��
		Thread t = new Thread(st, "�߳�1"); // �����������߳�
		t.start();
		for (int i = 1; i < 6; i++) {
			System.out.println(Thread.
					currentThread().getName() + ":" + i);
			if (i == 2) {
				t.join();					// �̲߳��
			}
		}
	}
}
class SubThread4 implements Runnable {
	public void run() { 					// ��дrun()����
		for (int i = 1; i < 6; i++) {
			System.out.println(Thread.
					currentThread().getName() + ":" + i);
		}
	}
}