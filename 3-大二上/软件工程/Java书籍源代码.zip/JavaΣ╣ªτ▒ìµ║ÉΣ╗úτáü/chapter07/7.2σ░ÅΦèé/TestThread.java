public class TestThread {
	public static void main(String[] args) {
		SubThread1 st1 = new SubThread1();	// ����SubThread1ʵ��
		SubThread1 st2 = new SubThread1();
		st1.start();						// �����߳�
		st2.start();
	}
}
class SubThread1 extends Thread {
	public void run() {						// ��дrun()����
		for (int i = 0; i < 4; i++) {
			if (i % 2 != 0) {
				System.out.println(Thread.
						currentThread().getName() + ":" + i);
			}
		}
	}
}