import java.lang.Thread.UncaughtExceptionHandler;
public class TestExceptionHandling {
	public static void main(String[] args) {
		Thread.currentThread().
			setUncaughtExceptionHandler(new MyHandler());
		int i = 10 / 0;
		System.out.println("������������");
	}
}
class MyHandler implements UncaughtExceptionHandler {
	public void uncaughtException(Thread t, Throwable e) {
		System.out.println(t + "�̳߳������쳣��" + e);
	}
}