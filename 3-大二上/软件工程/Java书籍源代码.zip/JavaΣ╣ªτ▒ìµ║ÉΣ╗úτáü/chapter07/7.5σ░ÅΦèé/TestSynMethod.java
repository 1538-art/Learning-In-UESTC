public class TestSynMethod {
	public static void main(String[] args) {
		Ticket3 ticket = new Ticket3();
		Thread t1 = new Thread(ticket);
		Thread t2 = new Thread(ticket);
		Thread t3 = new Thread(ticket);
		t1.start();
		t2.start();
		t3.start();
	}
}
class Ticket3 implements Runnable {
	private int ticket = 5;
	public synchronized void run() {
		for (int i = 0; i < 100; i++) {
			if (ticket > 0) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println(
						"������" + ticket + "��Ʊ����ʣ" + --ticket + "��Ʊ");
			}
		}
	}
}