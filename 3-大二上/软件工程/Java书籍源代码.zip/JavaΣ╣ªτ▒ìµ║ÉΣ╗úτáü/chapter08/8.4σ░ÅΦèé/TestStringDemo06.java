public class TestStringDemo06 {
	public static void main(String[] args) {
		String str1 = "1000phone.com";
		System.out.println(str1);
		String str2 = str1.toUpperCase();	// 将字符串转换为大写
		System.out.println(str2);
		String str3 = str2.toLowerCase();	// 将字符串转换为小写
		System.out.println(str3);
	}
}