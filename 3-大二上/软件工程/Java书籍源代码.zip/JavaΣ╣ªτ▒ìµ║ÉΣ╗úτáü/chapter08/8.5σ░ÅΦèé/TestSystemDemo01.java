public class TestSystemDemo01 {
	public static void main(String[] args) throws Exception {
		long start = System.currentTimeMillis();
		Thread.sleep(100);
		long end = System.currentTimeMillis();
		System.out.println("����˯����" + (end - start) + "����");
	}
}