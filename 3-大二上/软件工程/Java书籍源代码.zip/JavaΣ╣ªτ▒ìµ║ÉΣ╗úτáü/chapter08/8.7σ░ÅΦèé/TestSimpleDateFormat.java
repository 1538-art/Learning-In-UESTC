import java.text.SimpleDateFormat;
import java.util.Date;
public class TestSimpleDateFormat {
	public static void main(String[] args) throws Exception {
		// ����SimpleDateFormatʵ��
		SimpleDateFormat sdf = new SimpleDateFormat();
		String date = sdf.format(new Date());
		System.out.println("Ĭ�ϸ�ʽ��" + date);
		System.out.println("--------------------");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		date = sdf2.format(new Date());
		System.out.println("�Զ����ʽ1��" + date);
		System.out.println("--------------------");
		SimpleDateFormat sdf3 = 
				new SimpleDateFormat("Gyyyy-MM-dd hh:mm:ss:SSS");
		date = sdf3.format(new Date());
		System.out.println("�Զ����ʽ2��" + date);
	}
}