public class TestAutomatic {
	public static void main(String[] args) {
		Integer in = 10;		// 自动装箱成Integer
		System.out.println(in.toString());
		int i = in;				// 自动拆箱为int
		System.out.println(++i);
	}
}