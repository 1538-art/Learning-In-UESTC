public class TestBoxing {
	public static void main(String[] args) {
		int i = 10;
		Integer in = new Integer(i);
		System.out.println(in.equals(i));
	}
}