public class TestUnBoxing {
	public static void main(String[] args) {
		Integer in = new Integer("10");
		int i = 10;
		System.out.println(in.intValue() + i);
	}
}