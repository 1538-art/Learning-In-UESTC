public class TestTypeCast {
	public static void main(String[] args) {
		int n = 128;
		byte b = n;
		System.out.println(b);
	}
}
