public class TestIf {
	public static void main(String[] args) {
		double PI = 3.14;
		int r = -2;
		double perimeter = 0.0;
		double area = 0.0;
		if (r>=0) {
			perimeter = 2 * r * PI;
		}
		System.out.println("Բ�뾶"+ r +"���ܳ�Ϊ��" + perimeter);
		r = 6;
		if (r>=0) {
			area = r * r * PI;
		}
		System.out.println("Բ�뾶"+ r +"�����Ϊ��" + area);
		
	}
}