public class TestSwitchBreak {
	public static void main(String[] args) {
		char score = 'B';
		switch (score) {
			case 'A':
				System.out.println("case 'A':");
			case 'B':
				System.out.println("case 'B':");
			case 'C':
				System.out.println("case 'C':");
			case 'D':
				System.out.println("����");
				break;
			case 'E':
				System.out.println("������");
				break;
			default:
				System.out.println("�ɼ��������");
		}
	}
}
