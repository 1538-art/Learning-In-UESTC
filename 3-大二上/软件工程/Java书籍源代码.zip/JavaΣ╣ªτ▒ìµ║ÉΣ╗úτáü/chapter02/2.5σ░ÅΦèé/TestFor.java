public class TestFor {
	public static void main(String[] args) {
		int sum = 0;					//�ۼӺ�
		for (int i = 0; i <= 100; i++) {
			sum += i;					//�ۼӲ���
		}
		System.out.println("1~100���ۼӺͣ�" + sum);
	}
}