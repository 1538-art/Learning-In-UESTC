import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class TestJDialog {
	public static void main(String[] args) {
		JFrame jf = new JFrame("JFrame����"); 	// ����JFrame����
		JButton jb1 = new JButton("JDialog����1");
		JButton jb2 = new JButton("JDialog����2");
		jf.setLayout(new FlowLayout()); 		// ���ò���
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setSize(300, 250);
		jf.setVisible(true);
		jf.add(jb1);							// ���Ӱ�ť
		jf.add(jb2);
		final JLabel jLabel = new JLabel();
		final JDialog jd = new JDialog(jf, "JDialog����");
		jd.setSize(200, 150);
		jd.setLocation(50, 60);
		jd.setLayout(new FlowLayout());
		jb1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jd.setModal(true);
				if (jd.getComponents().length == 1) {
					jd.add(jLabel);
				}
				jLabel.setText("JDialog����1");
				jd.setVisible(true);
			}
		});
		jb2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jd.setModal(false);
				if (jd.getComponents().length == 1) {
					jd.add(jLabel);
				}
				jLabel.setText("JDialog����2");
				jd.setVisible(true);
			}
		});
	}
}