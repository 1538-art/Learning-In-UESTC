import java.awt.*;
import java.awt.event.*;
public class TestClose {
	public static void main(String[] args) {
		// ����Frame����
		Frame f = new Frame("Frame����");
		f.setSize(300, 200); 		// ���ó��Ϳ�
		f.setVisible(true);			// ����Ϊ�ɼ�
		ListenerClose lc = new ListenerClose();
		f.addWindowListener(lc);	// Ϊ����ע�������
	}
}
class ListenerClose implements WindowListener {
	public void windowClosing(WindowEvent e) {
		Window w = e.getWindow();
		w.setVisible(false);
		w.dispose();				// �ͷŴ���
	}
	public void windowOpened(WindowEvent e) {
	}
	public void windowClosed(WindowEvent e) {
	}
	public void windowIconified(WindowEvent e) {
	}
	public void windowDeiconified(WindowEvent e) {
	}
	public void windowActivated(WindowEvent e) {
	}
	public void windowDeactivated(WindowEvent e) {
	}
}