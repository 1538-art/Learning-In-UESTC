public class TestCallMethod {
	public static void main(String[] args) {
		int n = 5;
		int m =2;
		System.out.println("before main\t��n="+ n + ", m=" + m);
		swap(n, m);
		System.out.println("end main\t��n="+ n + ", m=" + m);
	}
	//����������
	public static void swap(int n, int m) {
		System.out.println("before swap\t��n="+ n + ", m=" + m);
		int tmp = n;
		n = m;
		m = tmp;
		System.out.println("end swap\t��n="+ n + ", m=" + m);
	}
}