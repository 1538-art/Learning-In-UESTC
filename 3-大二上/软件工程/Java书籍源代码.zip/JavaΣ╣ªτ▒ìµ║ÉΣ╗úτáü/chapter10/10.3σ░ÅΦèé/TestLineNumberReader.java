import java.io.*;
public class TestLineNumberReader {
	public static void main(String[] args) throws IOException {
		FileReader fr = new FileReader("code1.txt");
		FileWriter fw = new FileWriter("code2.txt");
		LineNumberReader lnr = new LineNumberReader(fr);
		lnr.setLineNumber(0); 	// �����ļ���ʼ�к�
		String str = null;
		while ((str = lnr.readLine()) != null) {
			// ���к�д���ļ�
			fw.write(lnr.getLineNumber() + ":" + str);
			fw.write("\r\n"); 	// д�뻻��
		}
		fw.close();				// �ͷ���Դ
		lnr.close();
	}
}