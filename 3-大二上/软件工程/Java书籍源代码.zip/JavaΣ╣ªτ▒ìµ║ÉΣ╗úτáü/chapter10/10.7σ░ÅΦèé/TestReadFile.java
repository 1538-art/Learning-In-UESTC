import java.io.*;
public class TestReadFile {
	public static void main(String[] args) throws Exception {
		FileInputStream fis = new FileInputStream("D:/test.txt");
		int len = 0;
		byte[] buffer = new byte[1024];
		while ((len = fis.read(buffer)) != -1) {
			System.out.println(new String(buffer, 0, len, "GBK"));
		}
		fis.close();
	}
}