import java.io.*;
public class TestFilter {
	public static void main(String[] args) {
		// ������
		FilenameFilter filter = new FilenameFilter() {
			public boolean accept(File dir, String name) {
				File currFile = new File(dir, name);
				if (currFile.isFile() && name.indexOf(".java") != -1) {
					return true;
				} else {
					return false;
				}
			}
		};
		// ����Ŀ¼����չ��Ϊ.java���ļ���
		String[] list = new File("D:/com/1000phone/chapter10/01").list(filter);
		for (int i = 0; i < list.length; i++) {
			System.out.println(list[i]);
		}
	}
}