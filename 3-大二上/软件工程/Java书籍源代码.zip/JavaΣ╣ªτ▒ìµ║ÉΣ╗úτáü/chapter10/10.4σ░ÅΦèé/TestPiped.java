import java.io.*;
public class TestPiped {
	public static void main(String[] args) throws IOException {
		Send send = new Send();
		Receive recive = new Receive();
		// д��
		PipedOutputStream pos = send.getOutputStream();
		// ����
		PipedInputStream pis = recive.getInputStream();
		pos.connect(pis);				// ��������͵�����
		send.start();					// �����߳�
		recive.start();
	}
}
class Send extends Thread {
	private PipedOutputStream pos = new PipedOutputStream();
	public PipedOutputStream getOutputStream() {
		return pos;
	}
	public void run() {
		String s = new String("Send���͵�����");
		try {
			pos.write(s.getBytes());	// д������
			pos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
class Receive extends Thread {
	private PipedInputStream pis = new PipedInputStream();
	public PipedInputStream getInputStream() {
		return pis;
	}
	public void run() {
		String s = null;
		byte[] b = new byte[1024];
		try {
			int len = pis.read(b);
			s = new String(b, 0, len);
			// ��������
			System.out.println("Receive���յ��ˣ�" + s);
			pis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}