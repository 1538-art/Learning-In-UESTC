import java.io.*;
import java.net.*;
public class TestServer {
	public static void main(String[] args) throws IOException {
		ServerSocket ss = new ServerSocket(9090);
		System.out.println("�ȴ���������...");
		Socket s = ss.accept();
		InputStream is = s.getInputStream();
		byte[] b = new byte[20];
		int len;
		while ((len = is.read(b)) != -1) {
			String str = new String(b, 0, len);
			System.out.print(str);
		}
		OutputStream os = s.getOutputStream();
		os.write("��������յ���Ϣ��".getBytes());
		os.close();
		is.close();
		s.close();
		ss.close();
	}
}