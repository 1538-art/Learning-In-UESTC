import java.io.*;
import java.net.*;
public class TestServerThread {
	public static void main(String[] args) throws IOException {
		ServerSocket ss = null;
		Socket s = null;
		ss = new ServerSocket(9090);
		boolean flag = true;
		while (flag) {
			System.out.println("�ȴ���������...");
			s = ss.accept();
			new Thread(new TestThread(s)).start();
		}
		ss.close();
		InputStream is = s.getInputStream();
		byte[] b = new byte[20];
		int len;
		while ((len = is.read(b)) != -1) {
			String str = new String(b, 0, len);
			System.out.print(str);
		}
		OutputStream os = s.getOutputStream();
		os.write("��������յ���Ϣ��".getBytes());
		os.close();
		is.close();
		s.close();
		ss.close();
	}
}