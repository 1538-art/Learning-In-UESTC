import java.util.*;
public class TestCollection {
	public static void main(String[] args) {
		Collection coll = new ArrayList();		//创建集合
		coll.add(1000);							//添加元素
		coll.add("phone");
		System.out.println(coll);				//打印集合coll
		System.out.println(coll.size());		//打印集合长度
		Collection coll1 = new HashSet();
		coll1.add(1000);
		coll1.add("phone");
		System.out.println(coll1);				//打印集合coll1
		coll.clear();							//清空集合
		System.out.println(coll.isEmpty());		//打印集合是否为空
	}
}
