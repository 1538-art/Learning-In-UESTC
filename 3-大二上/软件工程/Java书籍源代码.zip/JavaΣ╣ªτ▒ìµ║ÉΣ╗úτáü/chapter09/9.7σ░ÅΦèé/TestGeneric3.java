import java.util.*;
public class TestGeneric3 {
	public static void main(String[] args) {
		List<? extends Person> list = null;
		// list=new ArrayList<String>(); ������ʱ�쳣
		list = new ArrayList<Person>();
		list = new ArrayList<Man>();
		List<? super Man> list2 = null;
		// list=new ArrayList<String>(); ������ʱ�쳣
		list2 = new ArrayList<Person>();
		list2 = new ArrayList<Man>();
	}
}
class Person {
}
class Man extends Person {
}