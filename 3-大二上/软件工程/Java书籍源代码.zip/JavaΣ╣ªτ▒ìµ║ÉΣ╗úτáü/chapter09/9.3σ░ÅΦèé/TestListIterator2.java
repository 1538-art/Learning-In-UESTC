import java.util.*;
public class TestListIterator2 {
	public static void main(String[] args) {
		List list = new ArrayList();
		listIteratorDemo2(list);
	}
	public static void listIteratorDemo2(List list) {
		list.add("stu1");
		list.add("stu2");
		list.add("stu3");
		ListIterator it = list.listIterator();	// ��ȡ������
		while (it.hasNext()) {
			Object obj = it.next();
			if (obj.equals("stu2")) {
				it.add("hello");
			}
			System.out.println(obj);
		}
	}
}