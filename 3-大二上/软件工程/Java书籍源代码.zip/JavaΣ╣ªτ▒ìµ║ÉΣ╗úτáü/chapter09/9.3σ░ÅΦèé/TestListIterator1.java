import java.util.*;
public class TestListIterator1 {
	public static void main(String[] args) {
		List list = new ArrayList();
		listIteratorDemo(list);
	}
	public static void listIteratorDemo(List list) {
		list.add("stu1");
		list.add("stu2");
		list.add("stu3");
		Iterator it = list.iterator();		// ��ȡ������
		while (it.hasNext()) {
			// ConcurrentModificationException�����쳣
			Object obj = it.next();
			if (obj.equals("stu2")) {
				list.add("hello");
			}
			System.out.println(obj);
		}
	}
}