import java.util.PriorityQueue;
public class TestPriorityQueue {
	public static void main(String[] args) {
		PriorityQueue pq = new PriorityQueue();
		pq.offer(1);
		pq.offer(3);
		pq.offer(5);
		System.out.println(pq);
		System.out.println(pq.remove());
		System.out.println(pq);
	}
}