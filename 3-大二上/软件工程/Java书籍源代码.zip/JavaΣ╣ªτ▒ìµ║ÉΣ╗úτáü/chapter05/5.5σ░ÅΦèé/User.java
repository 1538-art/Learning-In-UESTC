package com.l000phone.www.javaTrain.user.domain;
public class User {
	private String name;
	public User(String name) {
		this.name = name;
	}
	public String toString() {
		return "User [name=" + name + "]";
	}
}