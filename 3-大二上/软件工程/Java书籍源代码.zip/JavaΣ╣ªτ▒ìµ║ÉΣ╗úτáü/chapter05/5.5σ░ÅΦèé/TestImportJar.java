package com.l000phone.www.javaTrain.test;
import com.l000phone.www.javaTrain.user.domain.*;

public class TestImportJar{
	public static void main(String[] args) {
		User user = new User("����");
		System.out.println(user);
	}
}