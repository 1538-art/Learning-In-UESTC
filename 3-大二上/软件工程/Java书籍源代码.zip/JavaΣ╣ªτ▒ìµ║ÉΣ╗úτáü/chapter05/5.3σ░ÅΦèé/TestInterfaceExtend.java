//��interface�����ӿ�
interface Person {
	void say();
}
//��extends�̳нӿ�
interface Parent extends Person {
	void work();
}
//��implementsʵ�������ӿ�
class Child implements Parent {
	public void work() {
		System.out.println("ѧϰ");
	}
	public void say() {
		System.out.println("Child");
	}
}
public class TestInterfaceExtend {
	public static void main(String[] args) {
		Child c = new Child();
		c.say();
		c.work();
	}
}