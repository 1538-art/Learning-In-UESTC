//��interface�����ӿ�
interface Person {
	void say();
}
interface Parent {
	void work();
}
//��implementsʵ�������ӿ�
class Child implements Person, Parent {
	public void work() {
		System.out.println("ѧϰ");
	}
	public void say() {
		System.out.println("Child");
	}
}
public class TestImplements{
	public static void main(String[] args) {
		Child c = new Child();
		c.say();
		c.work();
	}
}