class Person {
	private String name;
	private int age;
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
}

public class TestToString {
	public static void main(String[] args) {
		Person o = new Person("����", 18);
		//���ö����toString����
		System.out.println(o.toString());
		//ֱ�Ӵ�ӡ����
		System.out.println(o);
	}
}