/**
Դ����VariableCovert.java
*/
class VariableCovert{
	int globalV��
	int varCov;
	void setData(int global, int varCov){
		globalV = global;
		this.varCov = varCor;
	}
}
