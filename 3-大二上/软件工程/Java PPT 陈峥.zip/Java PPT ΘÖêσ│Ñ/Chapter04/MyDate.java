/**
Դ����MyDate.java
*/
class MyDate {
	int month = 6;
	int day = 7;
	int year = 2008;
	int week = 6;
	final int MAX_MONTH = 12;
	final int MAX_DAY = 31;
	final int MAX_WEEK = 7;
}
