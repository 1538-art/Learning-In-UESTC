class HelloWorldApp {
   public static void main(String args[]){
      System.out.println("Hello, Java World !");
   }//end of main method
}//end of class
