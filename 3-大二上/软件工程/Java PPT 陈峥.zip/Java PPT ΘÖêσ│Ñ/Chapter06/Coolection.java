/**
   Դ����Coolection.java
*/
interface Collection {
	int MAX_NUM=100;
	void add (Object objAdd);
	void delete (Object objDelet);
	Object find (Object objFind);
	int currentCount();
}
