/**
   Դ����TestFIFOQueue.java
*/
class TestFIFOQueue{
	public static void main(String args[]){
		Collection cVar = new FIFOQueue();
		Object objAdd = new Object();
		...
		cVar.add(objAdd);
		...
	}
}
