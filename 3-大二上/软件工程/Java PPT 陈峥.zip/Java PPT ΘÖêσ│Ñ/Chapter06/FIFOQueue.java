/**
   Դ����FIFOQueue.java
*/
class FIFOQueue implements Collection {
	public void add (Object objAdd){
		//add object code
	}
	public void delete (Object objDelet){
		//delete object code
	}
	public Object find (Object objFind){
		//find object code
	}
	public int currentCount(){
		//count object code
	}
}
