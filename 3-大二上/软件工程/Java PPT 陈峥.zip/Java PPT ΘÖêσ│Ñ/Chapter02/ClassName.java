/**
源程序：ClassName.java
*/
package  nameOfPackage;   
import  example.OtherClassName;   
class  ClassName {  
   int x, y;  
   public static void main(String args[]){ 
      System.out.println("Hello, World!"); 
   } 
} 
