class AppExa{
	int idInt;
	char idCh1,idCh2;
	float idFloat;
	boolean  idBool ;
	public static void main(String arg[]){
		boolean idBool = true;
		int x = 10;
		．．．
		while (idBool) {
			int x = 11;
			int idInt=1;
			．．．
		}
		．．．
	}
	public void testProg(){
		char idCh3;
		．．．
	}
}
