package model;

public class Course {
	
	private String id;
	private String name;
	private String credit;
	private String hour;
	private String teacherId;
	private String teacherName;
	
	public Course(String id, String name, String credit, String hour,
			String teacherId, String teacherName) {
		super();
		this.id = id;
		this.name = name;
		this.credit = credit;
		this.hour = hour;
		this.teacherId = teacherId;
		this.teacherName = teacherName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCredit() {
		return credit;
	}

	public void setCredit(String credit) {
		this.credit = credit;
	}

	public String getHour() {
		return hour;
	}

	public void setHour(String hour) {
		this.hour = hour;
	}

	public String getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(String teacherId) {
		this.teacherId = teacherId;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	
	
	

}
