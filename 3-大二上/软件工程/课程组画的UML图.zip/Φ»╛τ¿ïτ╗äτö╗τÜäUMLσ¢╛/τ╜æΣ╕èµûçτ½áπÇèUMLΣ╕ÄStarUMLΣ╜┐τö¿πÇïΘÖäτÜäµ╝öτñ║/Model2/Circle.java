
import java.util.*;

/**
 * 
 */
public class Circle implements IShape {

    /**
     * Default constructor
     */
    public Circle() {
    }

}