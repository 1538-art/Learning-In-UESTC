
import java.util.*;

/**
 * 
 */
public class Draw {

    /**
     * Default constructor
     */
    public Draw() {
    }


}