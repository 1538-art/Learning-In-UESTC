
import java.util.*;

/**
 * 
 */
public interface IShape {


}