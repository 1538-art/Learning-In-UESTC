
#include "ML_RCS.h"
#include "Blif.h"
#include <fstream>
#include <map>
using namespace std;
map<string, int> ComsumingTime ={{"and", 2},{"or", 3},{"not", 1}};

int main() {
    string Path = ".\\input\\sample.blif";
    ifstream blifInformation(Path);
    Netlist* netlist = ReadBlif(blifInformation);

    // ML_RCS�㷨
    unordered_map<string, int>Resouces = { {"and",2},{"or",1},{"not",1} };
    int delta = ML_RCS_Schedule(netlist->NetlistGates, Resouces);
    PrintSchedule(netlist);
    cout << "Minimize Cycle: " << delta+1 << endl;

    
    system("pause");
    delete netlist;
    return 0;
}