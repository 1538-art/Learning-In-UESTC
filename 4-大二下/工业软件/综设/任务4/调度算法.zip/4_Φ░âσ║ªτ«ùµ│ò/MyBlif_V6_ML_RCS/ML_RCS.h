#ifndef _ML_RCS_H
#define _ML_RCS_H
#include"Blif.h"

int ML_RCS_Schedule(unordered_map<string, Gate*>& BlifGates, unordered_map<string, int>& Resources);

#endif 

