#pragma once
#ifndef STRUTIL_H
#define STRUTIL_H

#include <string>
using namespace std;

void splitByOperator(const string& str, string& left, string& right,char& op);
#endif
