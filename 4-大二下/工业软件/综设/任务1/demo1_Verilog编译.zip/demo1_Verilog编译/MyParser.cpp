#include "MyParser.h"
#include "strutil.h"
#include <assert.h> 

Token Lexer::NextToken() {
    while (isspace(input[position])) {
        ++position;
    }

    if (position >= input.length()) {
        return Token(TokenType::EndOfInput, "");
    }

    char currentChar = input[position++];

    if (isalpha(currentChar)) { // Identifier or Keyword
        string identifier;
        while (isalnum(currentChar) || currentChar == '_') {
            identifier += currentChar;
            if (position < input.length()) {
                currentChar = input[position++];
            }
            else {
                break;
            }
        }
        position--; // Rollback the last character read
        if (keywords.count(identifier)) {
            return Token(TokenType::Keyword, identifier);
        }
        else {
            return Token(TokenType::Identifier, identifier);
        }
    }
    else if (currentChar == ',' || currentChar == ';' || currentChar == '=' || currentChar == '&' || currentChar == '|' || currentChar == '(' || currentChar == ')') {
        return Token(TokenType::Symbol, string(1, currentChar));
    }

    return Token(TokenType::EndOfInput, ""); // Unknown token
}

string Lexer::GetWholeExpression()
{
    string exp;
    while (isspace(input[position])) {
        ++position;
    }
    auto startpos = position;
    while (input[position] != ';')
    {
        position++;
    }

    return input.substr(startpos, position - startpos);
}


void  Parser::Parse() {
    auto moduleToken = lexer.NextToken();
    if (moduleToken.type != TokenType::Keyword || moduleToken.value != "module") {
        throw runtime_error("Expected 'module'");
    }
    auto moduleNameToken = lexer.NextToken();
    if (moduleNameToken.type != TokenType::Identifier) {
        throw runtime_error("Expected module name");
    }
    string moduleName = moduleNameToken.value;
    m_AstRoot = make_unique<ModuleNode>(moduleName);

    Module* pmod = new Module;
    pmod->modname = moduleName;
    m_module_map[moduleName] = pmod;
    // Parse parameter
    auto token = lexer.NextToken();
    while (token.type != TokenType::Symbol || token.value != ";") {
        if (token.type == TokenType::Keyword && (token.value == "input" || token.value == "output")) {
            bool isInput = (token.value == "input");
            token = lexer.NextToken(); // ��ȡ�˿���
            while (token.type == TokenType::Identifier) {
                PWire* param = new PWire;
                param->wiretype = isInput ? PWire::INPUT : PWire::OUTPUT;
                param->name = token.value;
                pmod->wires[token.value] = param;
                // ���˿����ӵ�AST���������ݽṹ��
                m_AstRoot->AddStatement(make_unique<WireNode>(token.value));

                token = lexer.NextToken();
                if (token.type == TokenType::Symbol && token.value == ",") {
                    token = lexer.NextToken(); // ��һ���˿���
                }
                else {
                    break; // ������ǰ�˿��б��Ľ���
                }
            }
        }
        else {
            token = lexer.NextToken();
        }
    }
    // Parse input and output port
    //...
    // Parse statements
    token = lexer.NextToken();
    while (token.type != TokenType::Keyword || token.value != "endmodule") {
        if (auto statement = ParseStatement(pmod, token, m_AstRoot)) {
            m_AstRoot->AddStatement(std::move(statement));
        }
        token = lexer.NextToken();
    }
}

unique_ptr<AstNode> Parser::ParseStatement(Module* pmod, Token token, unique_ptr<ModuleNode>& AstRoot) {
    if (token.type == TokenType::Keyword && token.value == "wire") {
        auto wireToken = lexer.NextToken();
        if (wireToken.type != TokenType::Identifier) {
            throw runtime_error("Expected wire name");
        }
        PWire* param = new PWire;
        param->wiretype = PWire::MIDDLE;
        param->name = wireToken.value;
        pmod->wires[wireToken.value] = param;
        // ����wire������Ҫ����AST�ڵ�
        return nullptr;
    }
    else if (token.type == TokenType::Keyword && token.value == "assign") {
        PGAssign* ass = new PGAssign;
        ass->parser(pmod, lexer, AstRoot);
        // ���ض�Ӧ��AST�ڵ㣬����б�Ҫ
        return nullptr;
    }
    else if (token.type == TokenType::Keyword && token.value == "always") {
        auto statement = ParseStatement(pmod, lexer.NextToken(), AstRoot);
        return make_unique<AlwaysNode>(move(statement));
    }
    else if (token.type == TokenType::Keyword && token.value == "if") {
        auto conditionToken = lexer.NextToken();
        auto trueStatement = ParseStatement(pmod, lexer.NextToken(), AstRoot);
        unique_ptr<AstNode> falseStatement = nullptr;
        auto nextToken = lexer.NextToken();
        if (nextToken.value == "else") {
            falseStatement = ParseStatement(pmod, lexer.NextToken(), AstRoot);
        }
        return make_unique<IfNode>(conditionToken.value, move(trueStatement), move(falseStatement));
    }

    // ����null���û�����ɽڵ�
    return nullptr;
}

bool Parser::is_in_wires(std::string& name) {
    for (const auto& moduleEntry : m_module_map) {
        if (moduleEntry.second->wires.count(name)) {
            return true;
        }
    }
    return false;
}

void PGAssign::parser(Module* pmod, Lexer& lexer,unique_ptr<ModuleNode>& moduleNode) {

    auto lhsToken = lexer.NextToken();
    auto opToken = lexer.NextToken();//=
    string r_exp = lexer.GetWholeExpression();

    unique_ptr<AstNode> assnode;
    assnode = make_unique<AssignNode>(lhsToken.value, r_exp);
    moduleNode->AddStatement(move(assnode));

    //get op and check if it is a PEBinary op
    char op;
    string lstr, rstr;
    splitByOperator(r_exp, lstr, rstr, op);
    
    PExpr* r_val = new PEBinary;
    r_val->parser(pmod, lexer, moduleNode,r_exp);
    
}

void PExpr::parser(Module* pmod, Lexer& lexer, unique_ptr<ModuleNode>& moduleNode, string exp) {
    char op;
    string lstr, rstr;
    splitByOperator(exp, lstr, rstr, op);

    if (lstr.size() > 0)
    {
       //assert(opToken.value == lstr);
       if(!pmod->is_in_wires(lstr))
           throw runtime_error("undefine variable"+ lstr);
       moduleNode->AddStatement(make_unique<WireNode>(lstr));
    }
    if (rstr.size()> 0)
    {
       PExpr* r_val = new PEBinary;
       r_val->parser(pmod,lexer, moduleNode, rstr);
    }
}
