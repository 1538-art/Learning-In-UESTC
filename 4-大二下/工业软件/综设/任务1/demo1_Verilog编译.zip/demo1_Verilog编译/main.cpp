#include "MyParser.h"
#include <fstream>
#include <sstream>

// ��ӡAST
void PrintAst(const AstNode* node, int depth = 0) {
    if (dynamic_cast<const ModuleNode*>(node)) {
        const auto& moduleNode = dynamic_cast<const ModuleNode*>(node);
        cout << string(depth * 2, ' ') << "Module: " << moduleNode->name << endl;
        for (const auto& statement : moduleNode->statements) {
            PrintAst(statement.get(), depth + 1);
        }
    }
    else if (dynamic_cast<const AssignNode*>(node)) {
        const auto& assignNode = dynamic_cast<const AssignNode*>(node);
        cout << string(depth * 2, ' ') << "Assign: " << assignNode->lhs << " = " << assignNode->rhs << endl;
    }
    else if (dynamic_cast<const WireNode*>(node)) {
        const auto& wireNode = dynamic_cast<const WireNode*>(node);
        cout << string(depth * 2, ' ') << "Wire: " << wireNode->name << endl;
    }
}

int main() {
    std::ifstream file("input.v"); // ����������ļ���Ϊinput.v
    if (!file.is_open()) {
        std::cerr << "�޷����ļ�" << std::endl;
        return 1;
    }

    std::stringstream buffer;
    buffer << file.rdbuf(); // ���ļ����ݶ��뵽�ַ�������
    std::string input = buffer.str(); // ���ַ�����ת��Ϊ�ַ���
    file.close();

    Lexer lexer(input);
    Parser parser(lexer);

    try {
        parser.Parse();
        PrintAst(parser.m_AstRoot.get());
    }
    catch (const std::runtime_error& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}