#pragma once
#ifndef MYPARSER_H
#define MYPARSER_H

#include "MyModule.h"
// AST�ڵ����
class AstNode {
public:
    virtual ~AstNode() = default;
};

class ModuleNode : public AstNode {
public:
    string name;
    //vector<pair<string, bool>> ports; // pair: <port_name, is_input>
    vector<unique_ptr<AstNode>> statements;

    ModuleNode(string name) : name(move(name)) {}

    void AddStatement(unique_ptr<AstNode> statement) {
        statements.push_back(move(statement));
    }
};

// ��ֵ���ڵ�
class AssignNode : public AstNode {
public:
    string lhs;
    string rhs;

    AssignNode(string lhs, string rhs) : lhs(move(lhs)), rhs(move(rhs)) {}
};

// ���������ڵ�
class WireNode : public AstNode {
public:
    string name;

    WireNode(string name) : name(move(name)) {}
};

// AlwaysNode��
class AlwaysNode : public AstNode {
public:
    explicit AlwaysNode(unique_ptr<AstNode> statement)
        : statement_(move(statement)) {}

private:
    unique_ptr<AstNode> statement_;
};

// IfNode��
class IfNode : public AstNode {
public:
    IfNode(const std::string& condition, unique_ptr<AstNode> trueStatement, unique_ptr<AstNode> falseStatement)
        : condition_(condition), trueStatement_(move(trueStatement)), falseStatement_(move(falseStatement)) {}

private:
    std::string condition_;
    unique_ptr<AstNode> trueStatement_;
    unique_ptr<AstNode> falseStatement_;
};

// ����ʷ���Ԫ������
enum class TokenType {
    Identifier,
    Keyword,
    Symbol,
    EndOfInput
};

// �ʷ���Ԫ��
class Token {
public:
    TokenType type;
    string value;

    Token(TokenType type, string value) : type(type), value(move(value)) {}
};

// �ʷ�������
class Lexer {
public:
    explicit Lexer(const string& input) : input(input), position(0) {}
    Token NextToken();
    string GetWholeExpression();
    //Token GetTokenFromSubExpression(string str);
private:
    const string input;
    size_t position;
    unordered_set<string> keywords = { "module", "input", "output", "wire", "assign", "endmodule" };
};

// �﷨������
class Parser {
public:
    explicit Parser(Lexer& lexer) : lexer(lexer) {}
    void Parse();
    unique_ptr<AstNode>  ParseStatement(Module* rmod,Token token, unique_ptr<ModuleNode>& moduleNode);
    bool is_in_wires(string& name);
    map<string, Module*> m_module_map;
    unique_ptr<ModuleNode> m_AstRoot;
private:
    Lexer& lexer;
};


struct PExpr {

    virtual void parser(Module* pmod, Lexer& lexer, unique_ptr<ModuleNode>& moduleNode, string exp);
    //virtual void print();
};

struct PEBinary : public PExpr {
    PExpr* left_;
    PExpr* right_;
    char op_;
    //void parser();
    //void print();
};

struct PGAssign {
    void parser(Module* pmod, Lexer& lexer, unique_ptr<ModuleNode>& moduleNode);
    //void print();
};

#endif